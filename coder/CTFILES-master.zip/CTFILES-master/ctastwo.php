<?php
for($n=200;$n>=0;$n--){
 echo $n ."<br>";
}




?>