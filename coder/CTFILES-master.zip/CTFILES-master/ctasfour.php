<?php
for($i=22;$i<=40;$i++){
    for($j=1;$j<=10;$j++){
        $result = $i*$j;
        echo $i."x".$j."=".$result."<br>";
    }
}
?>