<?php
function mathone($numberone,$numbertwo){
    $sum = $numberone+$numbertwo;
    $subtract = $numberone-$numbertwo;
    
    echo "Sum of the two Numbers is ".$sum."<br>"."Subtraction of two numbers is ".$subtract;
    
}

echo mathone(34,12)




?>